Tema Limbaje Formale si Automate - IMP Parser
Florin-Razvan Mihalache
336CB

    Pentru aceasta parte a temei, am plecat de la exemplul de JFlex dat de echipa,
preluand clasa Symbol si metoda de adaugare de taburi pentru afisarea AST-ului.

    Parsarea
    Mi-am facut gramatica pentru a face match pe limbajul din input

    Interpretarea
    // sa fii in paranteza: primul element din paranteza o paranteza, apoi &&