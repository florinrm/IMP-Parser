import java.*;
import java.util.*;

public interface Expression {
    String show();
    Expression interpret();
}